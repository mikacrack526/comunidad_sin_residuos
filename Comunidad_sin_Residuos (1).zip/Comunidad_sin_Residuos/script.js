// Menú adaptable para celulares
const menuBtn = document.getElementById("menuBtn");
const menu = document.getElementById("menu");

menuBtn.addEventListener("click", () => {
  const abierto = menu.classList.toggle("activo");
  menuBtn.setAttribute("aria-expanded", abierto);
});

document.querySelectorAll(".menu a").forEach(enlace => {
  enlace.addEventListener("click", () => {
    menu.classList.remove("activo");
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

// Año automático
document.getElementById("anio").textContent = new Date().getFullYear();

// Cuestionario
const preguntas = [
  {
    texto: "¿Cuál es una forma de prevenir residuos?",
    opciones: ["Usar bolsas reutilizables", "Comprar artículos de un solo uso", "Tirar objetos que aún sirven"],
    correcta: 0,
    explicacion: "¡Correcto! Una bolsa reutilizable evita consumir bolsas desechables."
  },
  {
    texto: "¿Cuál de estos residuos es orgánico?",
    opciones: ["Una lata", "Cáscara de fruta", "Una botella de vidrio"],
    correcta: 1,
    explicacion: "¡Muy bien! Las cáscaras de frutas son residuos orgánicos."
  },
  {
    texto: "¿Qué debemos hacer con las pilas usadas?",
    opciones: ["Tirarlas al suelo", "Quemarlas", "Llevarlas a un punto de recolección adecuado"],
    correcta: 2,
    explicacion: "¡Exacto! Las pilas requieren un manejo especial."
  },
  {
    texto: "¿Qué significa reutilizar?",
    opciones: ["Dar otro uso a un objeto", "Comprar algo nuevo", "Mezclar todos los residuos"],
    correcta: 0,
    explicacion: "¡Correcto! Reutilizar es aprovechar un objeto nuevamente."
  },
  {
    texto: "¿Quién puede ayudar a mantener limpia la comunidad?",
    opciones: ["Solo el personal de limpieza", "Todas las personas", "Nadie"],
    correcta: 1,
    explicacion: "¡Así es! El cuidado de la comunidad es responsabilidad compartida."
  }
];

let indice = 0;
let puntos = 0;
let contestada = false;

const pregunta = document.getElementById("pregunta");
const respuestas = document.getElementById("respuestas");
const mensaje = document.getElementById("mensaje");
const siguiente = document.getElementById("siguiente");
const contador = document.getElementById("contador");
const marcador = document.getElementById("marcador");
const progreso = document.getElementById("progreso");

function mostrarPregunta() {
  contestada = false;
  const actual = preguntas[indice];
  pregunta.textContent = actual.texto;
  contador.textContent = `Pregunta ${indice + 1} de ${preguntas.length}`;
  marcador.textContent = `${puntos} ${puntos === 1 ? "punto" : "puntos"}`;
  progreso.style.width = `${((indice + 1) / preguntas.length) * 100}%`;
  mensaje.textContent = "";
  respuestas.innerHTML = "";
  siguiente.disabled = true;
  siguiente.textContent = indice === preguntas.length - 1 ? "Ver resultado" : "Siguiente pregunta →";

  actual.opciones.forEach((opcion, numero) => {
    const boton = document.createElement("button");
    boton.type = "button";
    boton.textContent = opcion;
    boton.addEventListener("click", () => elegirRespuesta(numero));
    respuestas.appendChild(boton);
  });
}

function elegirRespuesta(numero) {
  if (contestada) return;
  contestada = true;

  const actual = preguntas[indice];
  const botones = respuestas.querySelectorAll("button");
  botones.forEach(boton => boton.disabled = true);

  if (numero === actual.correcta) {
    puntos++;
    mensaje.textContent = actual.explicacion;
    botones[numero].classList.add("correcta");
  } else {
    mensaje.textContent = `¡Buen intento! ${actual.explicacion}`;
    botones[numero].classList.add("incorrecta");
    botones[actual.correcta].classList.add("correcta");
  }

  marcador.textContent = `${puntos} ${puntos === 1 ? "punto" : "puntos"}`;
  siguiente.disabled = false;
}

siguiente.addEventListener("click", () => {
  if (!contestada) return;

  if (indice < preguntas.length - 1) {
    indice++;
    mostrarPregunta();
  } else {
    mostrarResultado();
  }
});

function mostrarResultado() {
  contador.textContent = "Cuestionario terminado";
  marcador.textContent = `${puntos} de ${preguntas.length} puntos`;
  progreso.style.width = "100%";
  pregunta.textContent = puntos === 5 ? "¡Excelente trabajo! 🌟" : "¡Gracias por participar! 🌱";
  respuestas.innerHTML = "";
  mensaje.textContent = `Obtuviste ${puntos} de ${preguntas.length} respuestas correctas. Sigue poniendo en práctica lo aprendido.`;
  siguiente.disabled = false;
  siguiente.textContent = "Volver a intentarlo";
  siguiente.onclick = reiniciar;
}

function reiniciar() {
  indice = 0;
  puntos = 0;
  siguiente.onclick = null;
  mostrarPregunta();
}

mostrarPregunta();
